<template>
  <Link :href="href" :class="active ? 'block w-full ps-3 pe-4 py-2 border-l-4 border-gray-400 text-start text-base font-medium text-gray-900 bg-gray-50 focus:outline-none focus:text-gray-900 focus:bg-gray-100 focus:border-gray-900 transition duration-150 ease-in-out' : 'block w-full ps-3 pe-4 py-2 border-l-4 border-transparent text-start text-base font-medium text-gray-600 hover:text-gray-800 hover:bg-gray-50 hover:border-gray-300 focus:outline-none focus:text-gray-800 focus:bg-gray-50 focus:border-gray-300 transition duration-150 ease-in-out'">
    <slot />
  </Link>
</template>
<script setup>
import { Link } from '@inertiajs/vue3';
defineProps({ href: String, active: Boolean })
</script>