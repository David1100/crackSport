<?php

use Livewire\Component;
use Livewire\Attributes\On;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

return new class extends Component
{
    public $users = [];
    public $showModal = false;
    public $editingId = null;
    public $name = '';
    public $email = '';
    public $password = '';
    public $password_confirmation = '';

    public function mount()
    {
        $this->loadUsers();
    }

    public function loadUsers()
    {
        $this->users = User::latest()->get();
    }

    public function openCreate()
    {
        $this->resetForm();
        $this->showModal = true;
    }

    public function openEdit($id)
    {
        $user = User::findOrFail($id);
        $this->editingId = $id;
        $this->name = $user->name;
        $this->email = $user->email;
        $this->showModal = true;
    }

    public function save()
    {
        $rules = [
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email' . ($this->editingId ? ',' . $this->editingId : ''),
        ];
        if (!$this->editingId || $this->password) {
            $rules['password'] = 'required|string|min:6|confirmed';
        }
        $this->validate($rules);

        $data = ['name' => $this->name, 'email' => $this->email];
        if ($this->password) {
            $data['password'] = Hash::make($this->password);
        }

        if ($this->editingId) {
            User::findOrFail($this->editingId)->update($data);
            $this->dispatch('swal', ['title' => 'Actualizado', 'icon' => 'success']);
        } else {
            $data['password'] = $data['password'] ?? Hash::make($this->password);
            User::create($data);
            $this->dispatch('swal', ['title' => 'Creado', 'icon' => 'success']);
        }

        $this->resetForm();
        $this->showModal = false;
        $this->loadUsers();
    }

    #[On('deleteUser')]
    public function handleDelete($id)
    {
        User::findOrFail($id)->delete();
        $this->loadUsers();
        $this->dispatch('swal', ['title' => 'Eliminado', 'icon' => 'success']);
    }

    public function delete($id)
    {
        $this->handleDelete($id);
    }

    private function resetForm()
    {
        $this->editingId = null;
        $this->name = '';
        $this->email = '';
        $this->password = '';
        $this->password_confirmation = '';
    }

    protected function view($data = [])
    {
        return app('view')->file('C:\Users\acevd\OneDrive\Desktop\carcksport\backend\storage\framework\views/livewire/views/223e5fe4.blade.php', $data);
    }
};
