<?php

use Livewire\Component;
use Livewire\Attributes\On;
use App\Models\Tela;
use Livewire\WithFileUploads;

return new class extends Component
{
    use WithFileUploads;
    public $telas = [];
    public $showModal = false;
    public $editingId = null;
    public $name = '';
    public $description = '';
    public $main_photo;
    public $photos = [];
    public $existingPhotos = [];

    public function mount() { $this->load(); }
    public function load() { $this->telas = Tela::latest()->get(); }
    public function openCreate() { $this->resetForm(); $this->showModal = true; }
    public function openEdit($id) {
        $t = Tela::findOrFail($id);
        $this->editingId = $id;
        $this->name = $t->name;
        $this->description = $t->description;
        $this->existingPhotos = $t->photos ?? [];
        $this->showModal = true;
    }
    public function save() {
        $this->validate(['name' => 'required|string|max:255', 'main_photo' => 'nullable|image|max:2048', 'photos.*' => 'nullable|image|max:2048']);
        $data = ['name' => $this->name, 'description' => $this->description];
        if ($this->main_photo) {
            $data['main_photo'] = $this->main_photo->store('telas', 'public');
        }
        if (!empty($this->photos)) {
            $paths = $this->existingPhotos;
            foreach ($this->photos as $p) { $paths[] = $p->store('telas', 'public'); }
            $data['photos'] = $paths;
        } elseif ($this->editingId) {
            $data['photos'] = $this->existingPhotos;
        }
        if ($this->editingId) {
            Tela::findOrFail($this->editingId)->update($data);
            $this->dispatch('swal', ['title' => 'Actualizado', 'icon' => 'success']);
        } else {
            Tela::create($data);
            $this->dispatch('swal', ['title' => 'Creado', 'icon' => 'success']);
        }
        $this->resetForm();
        $this->showModal = false;
        $this->load();
    }
    #[On('deleteTela')]
    public function handleDelete($id) {
        Tela::findOrFail($id)->delete();
        $this->load();
        $this->dispatch('swal', ['title' => 'Eliminado', 'icon' => 'success']);
    }
    public function deleteMainPhoto() {
        if ($this->editingId) {
            Tela::findOrFail($this->editingId)->update(['main_photo' => null]);
        }
        $this->main_photo = null;
    }
    public function deletePhoto($index) {
        unset($this->existingPhotos[$index]);
        $this->existingPhotos = array_values($this->existingPhotos);
        if ($this->editingId) {
            Tela::findOrFail($this->editingId)->update(['photos' => $this->existingPhotos]);
        }
    }
    private function resetForm() {
        $this->editingId = null;
        $this->name = '';
        $this->description = '';
        $this->main_photo = null;
        $this->photos = [];
        $this->existingPhotos = [];
    }

    protected function view($data = [])
    {
        return app('view')->file('C:\Users\acevd\OneDrive\Desktop\carcksport\backend\storage\framework\views/livewire/views/f9e7c9f6.blade.php', $data);
    }
};
