<?php

use Livewire\Component;
use Livewire\Attributes\On;
use App\Models\Category;
use Livewire\WithFileUploads;

return new class extends Component
{
    use WithFileUploads;
    public $categories = [];
    public $showModal = false;
    public $editingId = null;
    public $name = '';
    public $image;

    public function mount() { $this->load(); }
    public function load() { $this->categories = Category::latest()->get(); }
    public function openCreate() { $this->resetForm(); $this->showModal = true; }
    public function openEdit($id) {
        $c = Category::findOrFail($id);
        $this->editingId = $id;
        $this->name = $c->name;
        $this->showModal = true;
    }
    public function save() {
        $this->validate(['name' => 'required|string|max:255', 'image' => 'nullable|image|max:2048']);
        $data = ['name' => $this->name];
        if ($this->image) {
            $data['image'] = $this->image->store('categories', 'public');
        }
        if ($this->editingId) {
            Category::findOrFail($this->editingId)->update($data);
            $this->dispatch('swal', ['title' => 'Actualizado', 'icon' => 'success']);
        } else {
            Category::create($data);
            $this->dispatch('swal', ['title' => 'Creado', 'icon' => 'success']);
        }
        $this->resetForm();
        $this->showModal = false;
        $this->load();
    }
    #[On('deleteCategory')]
    public function handleDelete($id) {
        Category::findOrFail($id)->delete();
        $this->load();
        $this->dispatch('swal', ['title' => 'Eliminado', 'icon' => 'success']);
    }
    private function resetForm() {
        $this->editingId = null;
        $this->name = '';
        $this->image = null;
    }

    protected function view($data = [])
    {
        return app('view')->file('C:\Users\acevd\OneDrive\Desktop\carcksport\backend\storage\framework\views/livewire/views/2ba2f12b.blade.php', $data);
    }
};
