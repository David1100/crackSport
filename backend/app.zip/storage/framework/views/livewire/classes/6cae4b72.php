<?php

use Livewire\Component;
use Livewire\Attributes\On;
use App\Models\Product;
use App\Models\Category;
use Livewire\WithFileUploads;

return new class extends Component
{
    use WithFileUploads;
    public $products = [];
    public $categories = [];
    public $showModal = false;
    public $editingId = null;
    public $name = '';
    public $description = '';
    public $image;
    public $category_id = '';
    public $price = '';
    public $discount_price = '';

    public function mount() { $this->load(); $this->categories = Category::all(); }
    public function load() { $this->products = Product::with('category')->latest()->get(); }
    public function openCreate() { $this->resetForm(); $this->showModal = true; }
    public function openEdit($id) {
        $p = Product::findOrFail($id);
        $this->editingId = $id;
        $this->name = $p->name;
        $this->description = $p->description;
        $this->category_id = $p->category_id;
        $this->price = $p->price;
        $this->discount_price = $p->discount_price;
        $this->showModal = true;
    }
    public function save() {
        $this->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'category_id' => 'required|exists:categories,id',
            'price' => 'required|numeric|min:0',
            'discount_price' => 'nullable|numeric|min:0',
            'image' => 'nullable|image|max:2048',
        ]);
        $data = ['name' => $this->name, 'description' => $this->description, 'category_id' => $this->category_id, 'price' => $this->price, 'discount_price' => $this->discount_price ?: null];
        if ($this->image) {
            $data['image'] = $this->image->store('products', 'public');
        }
        if ($this->editingId) {
            Product::findOrFail($this->editingId)->update($data);
            $this->dispatch('swal', ['title' => 'Actualizado', 'icon' => 'success']);
        } else {
            Product::create($data);
            $this->dispatch('swal', ['title' => 'Creado', 'icon' => 'success']);
        }
        $this->resetForm();
        $this->showModal = false;
        $this->load();
    }
    #[On('deleteProduct')]
    public function handleDelete($id) {
        Product::findOrFail($id)->delete();
        $this->load();
        $this->dispatch('swal', ['title' => 'Eliminado', 'icon' => 'success']);
    }
    private function resetForm() {
        $this->editingId = null;
        $this->name = '';
        $this->description = '';
        $this->image = null;
        $this->category_id = '';
        $this->price = '';
        $this->discount_price = '';
    }

    protected function view($data = [])
    {
        return app('view')->file('C:\Users\acevd\OneDrive\Desktop\carcksport\backend\storage\framework\views/livewire/views/6cae4b72.blade.php', $data);
    }
};
