<?php
use Livewire\Component;
use Livewire\Attributes\On;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
?>

<div>
    <div class="mb-4 flex justify-between items-center">
        <h2 class="text-xl font-bold">Usuarios</h2>
        <button wire:click="openCreate" class="px-4 py-2 bg-black text-white text-sm font-bold uppercase rounded hover:bg-neutral-800">Nuevo usuario</button>
    </div>

    <div class="bg-white shadow-sm sm:rounded-lg overflow-hidden">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Nombre</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Email</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Creado</th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Acciones</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                @foreach ($users as $user)
                    <tr>
                        <td class="px-6 py-4 whitespace-nowrap">{{ $user->name }}</td>
                        <td class="px-6 py-4 whitespace-nowrap">{{ $user->email }}</td>
                        <td class="px-6 py-4 whitespace-nowrap">{{ $user->created_at->format('d/m/Y') }}</td>
                        <td class="px-6 py-4 whitespace-nowrap text-right space-x-2">
                            <button wire:click="openEdit({{ $user->id }})" class="text-indigo-600 hover:text-indigo-900">Editar</button>
                            <button type="button" onclick="confirmDelete({{ $user->id }})" class="text-red-600 hover:text-red-900">Eliminar</button>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>

    @if ($showModal)
    <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
            <div class="bg-white rounded-lg shadow-xl w-full max-w-md p-6">
                <h3 class="text-lg font-bold mb-4">{{ $editingId ? 'Editar' : 'Nuevo' }} usuario</h3>
                <form wire:submit="save">
                    <div class="mb-3">
                        <label class="block text-sm font-medium text-gray-700">Nombre</label>
                        <input wire:model="name" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm" required>
                        @error('name')<p class="text-red-600 text-sm">{{ $message }}</p>@enderror
                    </div>
                    <div class="mb-3">
                        <label class="block text-sm font-medium text-gray-700">Email</label>
                        <input type="email" wire:model="email" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm" required>
                        @error('email')<p class="text-red-600 text-sm">{{ $message }}</p>@enderror
                    </div>
                    <div class="mb-3">
                        <label class="block text-sm font-medium text-gray-700">Contraseña {{ $editingId ? '(opcional)' : '' }}</label>
                        <input type="password" wire:model="password" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm" {{ $editingId ? '' : 'required' }}>
                        @error('password')<p class="text-red-600 text-sm">{{ $message }}</p>@enderror
                    </div>
                    <div class="mb-4">
                        <label class="block text-sm font-medium text-gray-700">Confirmar contraseña</label>
                        <input type="password" wire:model="password_confirmation" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                    </div>
                    <div class="flex justify-end gap-2">
                        <button type="button" wire:click="$set('showModal', false)" class="px-4 py-2 text-sm text-gray-600 hover:underline">Cancelar</button>
                        <button type="submit" class="px-4 py-2 bg-black text-white text-sm font-bold uppercase rounded hover:bg-neutral-800">Guardar</button>
                    </div>
                </form>
            </div>
        </div>
    @endif
</div>