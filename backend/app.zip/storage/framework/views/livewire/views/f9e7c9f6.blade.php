<?php
use Livewire\Component;
use Livewire\Attributes\On;
use App\Models\Tela;
use Livewire\WithFileUploads;
?>

<div>
    <div class="mb-4 flex justify-between items-center">
        <h2 class="text-xl font-bold">Telas</h2>
        <button wire:click="openCreate" class="px-4 py-2 bg-black text-white text-sm font-bold uppercase rounded hover:bg-neutral-800">Nueva tela</button>
    </div>
    <div class="bg-white shadow-sm sm:rounded-lg overflow-hidden">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Foto principal</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Nombre</th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Acciones</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                @foreach ($telas as $t)
                    <tr>
                        <td class="px-6 py-4">
                            @if ($t->main_photo)
                                <img src="{{ asset('storage/' . $t->main_photo) }}" class="w-10 h-10 object-cover rounded" />
                            @endif
                        </td>
                        <td class="px-6 py-4">{{ $t->name }}</td>
                        <td class="px-6 py-4 text-right space-x-2">
                            <button wire:click="openEdit({{ $t->id }})" class="text-indigo-600 hover:text-indigo-900">Editar</button>
                            <button type="button" onclick="confirmDeleteTela({{ $t->id }})" class="text-red-600 hover:text-red-900">Eliminar</button>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>

    @if ($showModal)
    <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
        <div class="bg-white rounded-lg shadow-xl w-full max-w-md p-6">
            <h3 class="text-lg font-bold mb-4">{{ $editingId ? 'Editar' : 'Nueva' }} tela</h3>
            <form wire:submit="save" enctype="multipart/form-data">
                <div class="mb-3">
                    <label class="block text-sm font-medium text-gray-700">Nombre</label>
                    <input wire:model="name" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm" required>
                </div>
                <div class="mb-3">
                    <label class="block text-sm font-medium text-gray-700">Descripción</label>
                    <input id="tela-desc" type="hidden" wire:model.defer="description" />
                    <trix-editor input="tela-desc" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm min-h-[120px]"></trix-editor>
                </div>
                <div class="mb-3">
                    <label class="block text-sm font-medium text-gray-700">Foto principal</label>
                    @if ($editingId && (Tela::find($editingId)->main_photo ?? null))
                        <div class="relative inline-block mb-2">
                            <img src="{{ asset('storage/' . Tela::find($editingId)->main_photo) }}" class="w-16 h-16 object-cover rounded-lg shadow-md ring-1 ring-gray-200" />
                            <button type="button" wire:click="deleteMainPhoto" class="absolute top-1 -right-1 bg-red-600 hover:bg-red-700 text-white rounded-full w-4 h-4 flex items-center justify-center shadow transition" title="Eliminar">
                                <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                            </button>
                        </div>
                    @endif
                    <label class="mt-1 flex items-center justify-center gap-2 px-4 py-2 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:border-black hover:bg-gray-50 transition">
                        <svg class="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                        <span class="text-sm text-gray-600">Seleccionar foto principal</span>
                        <input type="file" wire:model="main_photo" class="hidden" />
                    </label>
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700">Fotos (múltiples)</label>
                    @if (!empty($existingPhotos))
                        <div class="flex gap-3 flex-wrap mb-3">
                            @foreach ($existingPhotos as $i => $p)
                                <div class="relative inline-block">
                                    <img src="{{ asset('storage/' . $p) }}" class="w-16 h-16 object-cover rounded-lg shadow-md ring-1 ring-gray-200" />
                                    <button type="button" wire:click="deletePhoto({{ $i }})" class="absolute top-1 -right-1 bg-red-600 hover:bg-red-700 text-white rounded-full w-4 h-4 flex items-center justify-center shadow transition" title="Eliminar">
                                        <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                                    </button>
                                </div>
                            @endforeach
                        </div>
                    @endif
                    <label class="mt-1 flex items-center justify-center gap-2 px-4 py-2 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:border-black hover:bg-gray-50 transition">
                        <svg class="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                        <span class="text-sm text-gray-600">Seleccionar fotos</span>
                        <input type="file" wire:model="photos" multiple class="hidden" />
                    </label>
                </div>
                <div class="flex justify-end gap-2">
                    <button type="button" wire:click="$set('showModal', false)" class="px-4 py-2 text-sm text-gray-600 hover:underline">Cancelar</button>
                    <button type="submit" class="px-4 py-2 bg-black text-white text-sm font-bold uppercase rounded hover:bg-neutral-800">Guardar</button>
                </div>
            </form>
        </div>
    </div>
    @endif
</div>