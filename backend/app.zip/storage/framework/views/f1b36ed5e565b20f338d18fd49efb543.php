<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title><?php echo e(config('app.name', 'CRS Sport')); ?></title>
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
        <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    </head>
    <body class="font-sans antialiased bg-gray-100">
        <div class="min-h-screen flex">
            <!-- Sidebar -->
            <aside class="w-64 bg-white text-black flex-shrink-0 border-r border-gray-200">
                <div class="p-6">
                    <a href="<?php echo e(route('dashboard')); ?>">
                        <img src="/logo_principal.webp" alt="CRS Sport" class="h-10 object-contain" />
                    </a>
                </div>
                <nav class="mt-4 space-y-1 px-3">
                    <a href="<?php echo e(route('dashboard')); ?>" wire:navigate class="flex items-center gap-3 px-4 py-2 rounded <?php echo e(request()->routeIs('dashboard') ? 'bg-black text-white' : 'text-black hover:bg-gray-100'); ?>">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0h6"/></svg>
                        Dashboard
                    </a>
                    <a href="<?php echo e(route('users.index')); ?>" wire:navigate class="flex items-center gap-3 px-4 py-2 rounded <?php echo e(request()->routeIs('users.*') ? 'bg-black text-white' : 'text-black hover:bg-gray-100'); ?>">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a4 4 0 00-3-3.87M9 20H4v-2a4 4 0 013-3.87m6-4.13a4 4 0 100-8 4 4 0 000 8zm6 0a3 3 0 100-6 3 3 0 000 6z"/></svg>
                        Usuarios
                    </a>
                    <a href="<?php echo e(route('categories.index')); ?>" wire:navigate class="flex items-center gap-3 px-4 py-2 rounded <?php echo e(request()->routeIs('categories.*') ? 'bg-black text-white' : 'text-black hover:bg-gray-100'); ?>">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 10h16M4 14h16M4 18h16"/></svg>
                        Categorías
                    </a>
                    <a href="<?php echo e(route('products.index')); ?>" wire:navigate class="flex items-center gap-3 px-4 py-2 rounded <?php echo e(request()->routeIs('products.*') ? 'bg-black text-white' : 'text-black hover:bg-gray-100'); ?>">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>
                        Productos
                    </a>
                    <a href="<?php echo e(route('telas.index')); ?>" wire:navigate class="flex items-center gap-3 px-4 py-2 rounded <?php echo e(request()->routeIs('telas.*') ? 'bg-black text-white' : 'text-black hover:bg-gray-100'); ?>">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 10h16M4 14h16M4 18h16"/></svg>
                        Telas
                    </a>
                </nav>
            </aside>

            <!-- Main -->
            <div class="flex-1 flex flex-col">
                <header class="bg-white shadow-sm">
                    <div class="px-6 py-4 flex justify-between items-center">
                        <h1 class="text-lg font-bold"><?php echo e(isset($header) ? strip_tags($header) : 'Panel'); ?></h1>
                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="text-sm text-gray-600 hover:text-black">Cerrar sesión</button>
                        </form>
                    </div>
                </header>
                <main class="flex-1 p-6">
                    <?php echo e($slot); ?>

                </main>
            </div>
        </div>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
            <script>document.addEventListener('DOMContentLoaded', () => Swal.fire({ title: '<?php echo e(session('success')); ?>', icon: 'success', timer: 1500, showConfirmButton: false }));</script>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('error')): ?>
            <script>document.addEventListener('DOMContentLoaded', () => Swal.fire({ title: '<?php echo e(session('error')); ?>', icon: 'error', timer: 2000, showConfirmButton: false }));</script>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <link rel="stylesheet" href="https://unpkg.com/trix@2.0.8/dist/trix.css">
        <script src="https://unpkg.com/trix@2.0.8/dist/trix.umd.min.js"></script>
        <script>
            window.fmt = function(tag) {
                const ta = document.getElementById('tela-desc');
                if (!ta) return;
                const start = ta.selectionStart, end = ta.selectionEnd;
                const sel = ta.value.substring(start, end);
                const before = ta.value.substring(0, start);
                const after = ta.value.substring(end);
                let ins = '';
                if (tag === 'br') ins = '<br>';
                else ins = '<' + tag + '>' + (sel || 'texto') + '</' + tag + '>';
                ta.value = before + ins + after;
                ta.dispatchEvent(new Event('input'));
                ta.focus();
            };
        </script>
        <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
        <script src="https://cdn.quilljs.com/1.3.6/quill.min.js"></script>
        <script>
            document.addEventListener('livewire:init', () => {
                Livewire.on('swal', (e) => {
                    const d = Array.isArray(e) ? e[0] : e;
                    Swal.fire({ title: d.title, icon: d.icon, timer: 1500, showConfirmButton: false });
                });
            });
            window.confirmDeleteCat = function (id) {
                Swal.fire({ title: '¿Eliminar categoría?', icon: 'warning', showCancelButton: true, confirmButtonText: 'Sí, eliminar', cancelButtonText: 'Cancelar' }).then((r) => {
                    if (r.isConfirmed) {
                        Livewire.dispatch('deleteCategory', { id: id });
                    }
                });
            };
            window.confirmDeleteProd = function (id) {
                Swal.fire({ title: '¿Eliminar producto?', icon: 'warning', showCancelButton: true, confirmButtonText: 'Sí, eliminar', cancelButtonText: 'Cancelar' }).then((r) => {
                    if (r.isConfirmed) {
                        Livewire.dispatch('deleteProduct', { id: id });
                    }
                });
            };
            window.confirmDeleteTela = function (id) {
                Swal.fire({ title: '¿Eliminar tela?', icon: 'warning', showCancelButton: true, confirmButtonText: 'Sí, eliminar', cancelButtonText: 'Cancelar' }).then((r) => {
                    if (r.isConfirmed) {
                        Livewire.dispatch('deleteTela', { id: id });
                    }
                });
            };
            window.confirmDelete = function (id) {
                Swal.fire({ title: '¿Eliminar usuario?', icon: 'warning', showCancelButton: true, confirmButtonText: 'Sí, eliminar', cancelButtonText: 'Cancelar' }).then((r) => {
                    if (r.isConfirmed) {
                        Livewire.dispatch('deleteUser', { id: id });
                    }
                });
            };
        </script>
    </body>
</html><?php /**PATH C:\Users\acevd\OneDrive\Desktop\carcksport\backend\resources\views/layouts/app.blade.php ENDPATH**/ ?>